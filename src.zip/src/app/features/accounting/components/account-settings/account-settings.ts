import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { NotificationApi } from '../../../../core/services/notification-api';
import { TextField } from '../../../../shared/components/fields/text-field';
import { Icon } from '../../../../shared/components/icon/icon';
import { PageHeader } from '../../../../shared/components/page-header/page-header';
import { AccountingSettingsService } from '../../services/accounting-settings.service';

@Component({
  selector: 'app-account-settings',
  imports: [ReactiveFormsModule, PageHeader, TextField, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './account-settings.html',
  styleUrl: './account-settings.css',
})
export class AccountSettingsPage {
  private readonly api = inject(AccountingSettingsService);
  private readonly notify = inject(NotificationApi);

  protected readonly fields: readonly { control: string; label: string }[] = [
    { control: 'groupAccountLength', label: 'گروه حساب‌های کل' },
    { control: 'generalAccountLength', label: 'حساب‌های کل' },
    { control: 'subsidiaryAccountLength', label: 'حساب‌های معین' },
    { control: 'detailAccountLength', label: 'حساب‌های تفصیلی' },
    { control: 'detailClassCodeLength', label: 'طبقه تفصیلی' },
  ];

  protected readonly form = new FormGroup({
    groupAccountLength: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^\d+$/)] }),
    generalAccountLength: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^\d+$/)] }),
    subsidiaryAccountLength: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^\d+$/)] }),
    detailAccountLength: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^\d+$/)] }),
    detailClassCodeLength: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.pattern(/^\d+$/)] }),
  });

  protected readonly loading = signal(true);
  protected readonly loadFailed = signal(false);
  protected readonly busy = signal(false);

  constructor() {
    void this.load();
  }

  protected async load(): Promise<void> {
    this.loading.set(true);
    this.loadFailed.set(false);
    this.form.disable();
    try {
      const settings = await firstValueFrom(this.api.get());
      this.form.reset({
        groupAccountLength: this.asText(settings.groupAccountCodeLength),
        generalAccountLength: this.asText(settings.generalAccountLength),
        subsidiaryAccountLength: this.asText(settings.subsidiaryAccountLength),
        detailAccountLength: this.asText(settings.detailAccountLength),
        detailClassCodeLength: this.asText(settings.detailClassCodeLength),
      });
    } catch {
      this.loadFailed.set(true);
    } finally {
      this.form.enable();
      this.loading.set(false);
    }
  }

  protected async submit(): Promise<void> {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const raw = this.form.getRawValue();
    this.busy.set(true);
    try {
      await firstValueFrom(this.api.update({
        groupAccountLength: Number(raw.groupAccountLength),
        generalAccountLength: Number(raw.generalAccountLength),
        subsidiaryAccountLength: Number(raw.subsidiaryAccountLength),
        detailAccountLength: Number(raw.detailAccountLength),
        detailClassCodeLength: Number(raw.detailClassCodeLength),
      }));
      this.notify.success('تنظیم حساب‌ها ذخیره شد.');
      this.form.markAsPristine();
    } catch {
      // 400 / other failures are surfaced by the interceptor; the form keeps the user's input.
    } finally {
      this.busy.set(false);
    }
  }

  private asText(value: number | null | undefined): string {
    return value === null || value === undefined ? '' : String(value);
  }
}
